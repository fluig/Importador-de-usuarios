package br.com.bravatec.webdesk.util;

public class SimpleResult {
	private String resultXML;

	public String getResultXML() {
		return resultXML;
	}

	public void setResultXML(String resultXML) {
		this.resultXML = resultXML;
	}
}
