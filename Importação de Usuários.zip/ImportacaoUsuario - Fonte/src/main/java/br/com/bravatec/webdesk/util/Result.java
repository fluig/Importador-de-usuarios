package br.com.bravatec.webdesk.util;

import java.util.List;

public class Result {
	private List<Group> item;

	public List<Group> getResult() {
		return item;
	}

	public void setResult(List<Group> item) {
		this.item = item;
	}
	
}
