package br.com.bravatec.webdesk.util;

import java.util.List;

public class ColleagueResult {
	private List<Colleague> colab;

	public List<Colleague> getColab() {
		return colab;
	}

	public void setColab(List<Colleague> colab) {
		this.colab = colab;
	}
}
