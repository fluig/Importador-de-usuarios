package br.com.bravatec.webdesk.util;

public class RoleResult {
	private String createWorkflowRoleResult;
	private String faultcode;

	public String getCreateWorkflowRoleResult() {
		return createWorkflowRoleResult;
	}

	public void setCreateWorkflowRoleResult(String createWorkflowRoleResult) {
		this.createWorkflowRoleResult = createWorkflowRoleResult;
	}

	public String getFaultcode() {
		return faultcode;
	}

	public void setFaultcode(String faultcode) {
		this.faultcode = faultcode;
	}
}
